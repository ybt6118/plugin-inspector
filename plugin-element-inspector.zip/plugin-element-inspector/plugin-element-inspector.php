<?php
/**
 * Plugin Name:       Plugin Element Inspector
 * Description:       Find out which plugin generates each element on your pages (Elementor widgets, shortcodes, Gutenberg blocks, scripts & styles) and which plugins are not used anywhere in your content.
 * Version:           1.0.0
 * Author:            Uniczen
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * Text Domain:       plugin-element-inspector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PEI_VERSION', '1.0.0' );
define( 'PEI_FILE', __FILE__ );
define( 'PEI_PATH', plugin_dir_path( __FILE__ ) );
define( 'PEI_URL', plugin_dir_url( __FILE__ ) );

require_once PEI_PATH . 'includes/class-pei-resolver.php';
require_once PEI_PATH . 'includes/class-pei-scanner.php';
require_once PEI_PATH . 'includes/class-pei-admin.php';
require_once PEI_PATH . 'includes/class-pei-frontend.php';

add_action( 'plugins_loaded', array( 'PEI_Admin', 'init' ) );
add_action( 'plugins_loaded', array( 'PEI_Frontend', 'init' ) );

register_uninstall_hook( __FILE__, 'pei_uninstall' );
function pei_uninstall() {
	delete_option( 'pei_scan_results' );
}
